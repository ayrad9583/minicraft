# Mini Craft

Jeu navigateur 3D en HTML, basé sur Three.js.

## Publier sur Render
1. Ajoutez `index.html` et ce README à un dépôt GitHub.
2. Dans Render, choisissez **New + → Static Site** et connectez ce dépôt.
3. Réglez **Build Command** sur vide et **Publish Directory** sur `.`.
4. Cliquez sur **Create Static Site**.

Le jeu charge Three.js depuis un CDN et a donc besoin d'une connexion Internet.
