# Mini Craft — monde agrandi et biomes

Version HTML autonome à publier comme site statique sur Render.

## Déploiement Render
- Type : **Static Site**
- Build Command : laisser vide
- Publish Directory : `.`

Le jeu utilise Three.js depuis un CDN, donc une connexion Internet est nécessaire pour charger le moteur.
